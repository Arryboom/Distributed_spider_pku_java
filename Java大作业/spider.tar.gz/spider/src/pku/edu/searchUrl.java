package pku.edu;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.LinkedList;

import org.wltea.analyzer.core.IKSegmenter;
import org.wltea.analyzer.core.Lexeme;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.examples.WordCount.TokenizerMapper;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import pku.edu.disSpiderFilter.IntSumReducer;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class searchUrl {
	public static class collectUrl extends Mapper<NullWritable,NullWritable, Text, NullWritable>{
		public LinkedList<String> isVisited =new LinkedList<String>();
		public LinkedList<String> unVisited =new LinkedList<String>();
		private Text url=new Text();
		 @SuppressWarnings("deprecation")
			public void setup(Context context){
	        	Path[] patternsFiles=new Path[0];
	        	try {
					patternsFiles=DistributedCache.getLocalCacheFiles(context.getConfiguration());
					System.out.println("success read");
				} catch (Exception e) {
					// TODO: handle exception
				}
	        	if(patternsFiles == null){  
	                System.out.println("have no stopfile\n");  
	                return;  
	            }  
	              
	            //read stop-words into HashSet  
	            for (Path patternsFile : patternsFiles) {  
	               //unVisited.add(patternsFile.toString());
	                unVisited.addLast(patternsFile.toString());
	            }  
	        }
		public void map(NullWritable key,NullWritable value,Context context){
			while(true){
			String str=unVisited.removeFirst().toString();
			WebClient webClient=new WebClient(BrowserVersion.FIREFOX_24);
			webClient.getOptions().setJavaScriptEnabled(true);
			webClient.getOptions().setCssEnabled(false);
			webClient.getOptions().setActiveXNative(false);
			webClient.getOptions().setDoNotTrackEnabled(false);
			webClient.getOptions().setRedirectEnabled(true);
			webClient.getOptions().setThrowExceptionOnScriptError(false);
			 webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
			 webClient.getOptions().setTimeout(2000);
			try {
				HtmlPage page=webClient.getPage(str);
				if(page.asText()!=null){
					if (str.startsWith("http://sports.sina.com.cn/g/")) {;
					}
					
					
				
				isVisited.addLast(str);
				url.set(str);
				context.write(url,NullWritable.get());
				if(isVisited.size()>100000){
					break;
				}
				java.util.List<HtmlAnchor> achList=page.getAnchors();
				for(HtmlAnchor ach:achList){
					String con=ach.getHrefAttribute().toString();
					if ((isVisited.contains(con)==false)&&(unVisited.contains(con)==false)) {
						if (con.startsWith("http://sports.sina.com.cn/g/")) {
							
						}
						unVisited.addLast(con);
						//System.out.println(con);

					}

				 }
				}
			webClient.closeAllWindows();
		
			} catch (Exception e) {
				// TODO: handle exception
				return ;
			}
			
			
		}
		}
		
	}
	public static class downHtmlText extends Reducer<Text, NullWritable, Text, NullWritable>{
		private Text result=new Text();
		public void reduce(Text key, Iterable<NullWritable> values,Context context){
			
			String str=key.toString();
			WebClient webClient=new WebClient(BrowserVersion.FIREFOX_24);
			webClient.getOptions().setJavaScriptEnabled(true);
			webClient.getOptions().setCssEnabled(false);
			webClient.getOptions().setActiveXNative(false);
			webClient.getOptions().setDoNotTrackEnabled(false);
			webClient.getOptions().setRedirectEnabled(true);
			webClient.getOptions().setThrowExceptionOnScriptError(false);
			webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
			webClient.getOptions().setTimeout(2000);
			try {
				HtmlPage page=webClient.getPage(str);
				if(page.asText()!=null){
					if (str.startsWith("http://sports.sina.com.cn/g/")) {
						//downHtmlFile(page);
						result.set(page.asText().toString());
						context.write(result, NullWritable.get());
					}
				}
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

	/**
	 * @param args
	 * @throws IOException 
	 * @throws IllegalArgumentException 
	 */
	public static void main(String[] args) throws IllegalArgumentException, IOException {
		// TODO Auto-generated method stub
		 Configuration conf = new Configuration();
		  String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        //第一个job的配置  
        Job job1 = new Job(conf);  
        job1.setJarByClass(searchUrl.class);   
  
        job1.setMapperClass(collectUrl.class);   
        job1.setReducerClass(downHtmlText.class);   
  
        job1.setMapOutputKeyClass(Text.class);//map阶段的输出的key   
        job1.setMapOutputValueClass(IntWritable.class);//map阶段的输出的value   
      
        job1.setOutputKeyClass(Text.class);//reduce阶段的输出的key   
        job1.setOutputValueClass(IntWritable.class);//reduce阶段的输出的value   
          
        //加入控制容器   
        ControlledJob ctrljob1=new  ControlledJob(conf);   
        ctrljob1.setJob(job1);   
        //job1的输入输出文件路径  
        FileInputFormat.addInputPath(job1, new Path(args[0]));   
        FileOutputFormat.setOutputPath(job1, new Path(args[1]));   
  
        //第二个job的配置  
        Job job2=new Job(conf,"Join2");   
        job2.setJarByClass(disSpiderFilter.class);   
          
        job2.setMapperClass(TokenizerMapper.class);
        job2.setReducerClass(IntSumReducer.class);
         
        job2.setMapOutputKeyClass(Text.class);//map阶段的输出的key   
        job2.setMapOutputValueClass(IntWritable.class);//map阶段的输出的value   
  
        job2.setOutputKeyClass(Text.class);//reduce阶段的输出的key   
        job2.setOutputValueClass(IntWritable.class);//reduce阶段的输出的value   
  
        //作业2加入控制容器   
        ControlledJob ctrljob2=new ControlledJob(conf);   
        ctrljob2.setJob(job2);   
      
       //设置多个作业直接的依赖关系   
       //如下所写：   
       //意思为job2的启动，依赖于job1作业的完成   
      
        ctrljob2.addDependingJob(ctrljob1);   
          
        //输入路径是上一个作业的输出路径，因此这里填args[1],要和上面对应好  
        FileInputFormat.addInputPath(job2, new Path(args[1]));  
          
  
        FileOutputFormat.setOutputPath(job2,new Path(args[2]) );  
  
  
        JobControl jobCtrl=new JobControl("all");   
      

        jobCtrl.addJob(ctrljob1);   
        jobCtrl.addJob(ctrljob2);   
  
  
        Thread  t=new Thread(jobCtrl);   
        t.start();   
  
        while(true){   
  
        if(jobCtrl.allFinished()){//如果作业成功完成，就打印成功作业的信息   
        System.out.println(jobCtrl.getSuccessfulJobList());   
        jobCtrl.stop();   
        break;   
        }  
        }  
        }  
	}


